package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JList;
import javax.swing.JTextField;

public class search extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					search frame = new search();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public search() {

		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setResizable(false);
		setBounds(100, 100, 450, 543);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(28, 24, 98, 23);
		panel.setToolTipText("");
		contentPane.add(panel);
		
		JLabel label = new JLabel("\u038C\u03BD\u03BF\u03BC\u03B1 ");
		panel.add(label);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(28, 58, 98, 23);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("\u0395\u03C0\u03AF\u03B8\u03B5\u03C4\u03BF");
		panel_1.add(lblNewLabel);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(28, 92, 98, 24);
		contentPane.add(panel_2);
		
		JLabel label_1 = new JLabel("\u0391\u03C1.\u03A4\u03B1\u03C5\u03C4\u03CC\u03C4\u03B7\u03C4\u03B1\u03C2");
		panel_2.add(label_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(28, 127, 98, 23);
		contentPane.add(panel_3);
		
		JLabel lblNewLabel_1 = new JLabel("\u0391\u03C3\u03B8\u03AD\u03BD\u03B5\u03B9\u03B1");
		panel_3.add(lblNewLabel_1);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(28, 161, 98, 23);
		contentPane.add(panel_4);
		
		JLabel label_2 = new JLabel("\u0397\u03BB\u03B9\u03BA\u03AF\u03B1");
		panel_4.add(label_2);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(28, 195, 112, 24);
		contentPane.add(panel_5);
		
		JLabel lblNewLabel_2 = new JLabel("\u03A4\u03B5\u03BB\u03B5\u03C5\u03C4\u03B1\u03AF\u03BF \u03A1\u03B1\u03BD\u03C4\u03B5\u03B2\u03BF\u03C5");
		panel_5.add(lblNewLabel_2);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBounds(28, 230, 98, 23);
		contentPane.add(panel_6);
		
		JLabel label_3 = new JLabel("\u039A\u03B1\u03C4\u03AC\u03C3\u03C4\u03B1\u03C3\u03B7");
		panel_6.add(label_3);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBounds(28, 332, 98, 23);
		contentPane.add(panel_7);
		
		JLabel lblNewLabel_3 = new JLabel("\u03A3\u03C5\u03BD\u03C4\u03B1\u03B3\u03AE");
		panel_7.add(lblNewLabel_3);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBounds(10, 439, 412, 39);
		contentPane.add(panel_8);
		
		JButton btnNewButton = new JButton("\u0391\u03BD\u03B1\u03B6\u03AE\u03C4\u03B7\u03C3\u03B7 \u0391\u03C3\u03B8\u03B5\u03BD\u03AE");
		panel_8.add(btnNewButton);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBounds(216, 24, 125, 30);
		contentPane.add(panel_9);
		
		textField = new JTextField();
		panel_9.add(textField);
		textField.setColumns(10);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBounds(216, 58, 125, 30);
		contentPane.add(panel_10);
		
		textField_1 = new JTextField();
		panel_10.add(textField_1);
		textField_1.setColumns(10);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBounds(216, 92, 125, 30);
		contentPane.add(panel_11);
		
		textField_2 = new JTextField();
		panel_11.add(textField_2);
		textField_2.setColumns(10);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBounds(216, 127, 125, 30);
		contentPane.add(panel_12);
		
		textField_3 = new JTextField();
		panel_12.add(textField_3);
		textField_3.setColumns(10);
		
		JPanel panel_13 = new JPanel();
		panel_13.setBounds(216, 161, 125, 30);
		contentPane.add(panel_13);
		
		textField_4 = new JTextField();
		panel_13.add(textField_4);
		textField_4.setColumns(10);
		
		JPanel panel_14 = new JPanel();
		panel_14.setBounds(216, 195, 125, 30);
		contentPane.add(panel_14);
		
		textField_5 = new JTextField();
		panel_14.add(textField_5);
		textField_5.setColumns(10);
		
		JPanel panel_15 = new JPanel();
		panel_15.setBounds(216, 230, 125, 30);
		contentPane.add(panel_15);
		
		textField_6 = new JTextField();
		panel_15.add(textField_6);
		textField_6.setColumns(10);
		
		JPanel panel_16 = new JPanel();
		panel_16.setBounds(216, 264, 125, 30);
		contentPane.add(panel_16);
		
		textField_7 = new JTextField();
		panel_16.add(textField_7);
		textField_7.setColumns(10);
		
		JPanel panel_17 = new JPanel();
		panel_17.setBounds(28, 366, 98, 23);
		contentPane.add(panel_17);
		
		JLabel lblNewLabel_4 = new JLabel("\u0393\u03B9\u03B1\u03C4\u03C1\u03CC\u03C2");
		panel_17.add(lblNewLabel_4);
		
		JPanel panel_18 = new JPanel();
		panel_18.setBounds(216, 298, 125, 30);
		contentPane.add(panel_18);
		
		textField_8 = new JTextField();
		panel_18.add(textField_8);
		textField_8.setColumns(10);
		
		JPanel panel_19 = new JPanel();
		panel_19.setBounds(28, 264, 98, 23);
		contentPane.add(panel_19);
		
		JLabel lblNewLabel_5 = new JLabel("\u03A0\u03CC\u03BB\u03B7");
		panel_19.add(lblNewLabel_5);
		
		JPanel panel_20 = new JPanel();
		panel_20.setBounds(28, 298, 98, 23);
		contentPane.add(panel_20);
		
		JLabel label_4 = new JLabel("\u0394\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7");
		panel_20.add(label_4);
		
		JPanel panel_21 = new JPanel();
		panel_21.setBounds(216, 332, 125, 30);
		contentPane.add(panel_21);
		
		textField_9 = new JTextField();
		panel_21.add(textField_9);
		textField_9.setColumns(10);
		
		JPanel panel_22 = new JPanel();
		panel_22.setBounds(216, 366, 125, 30);
		contentPane.add(panel_22);
		
		textField_10 = new JTextField();
		panel_22.add(textField_10);
		textField_10.setColumns(10);
	}
}
