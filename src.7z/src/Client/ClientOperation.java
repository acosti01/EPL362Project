package Client;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import javax.swing.JOptionPane;

import Entities.Staff;
import Interface.RMIInterface;
import Server.Homepage;

public class ClientOperation {

	private static RMIInterface look_up;

	public static void main(String[] args)
		throws MalformedURLException, RemoteException, NotBoundException, InterruptedException {

		look_up = (RMIInterface) Naming.lookup("//localhost/MyServer");
		Homepage h=new Homepage();		
		while (h.ready==false){	
		Thread.sleep(1);	
		}
		String response = look_up.helloTo(h.username);
		//validation
		Staff temp=look_up.getStaffObject("a");
		//StaffInterface StaffInt=look_up.getStaffInterface();
		//while ()
		JOptionPane.showMessageDialog(null, temp.getName());

	}

}