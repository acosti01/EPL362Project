package Interface;

import java.rmi.Remote;
import java.rmi.RemoteException;

import Entities.Staff;

public interface RMIInterface extends Remote {

    public String helloTo(String name) throws RemoteException;

	public Staff getStaffObject(String username)throws RemoteException;


}