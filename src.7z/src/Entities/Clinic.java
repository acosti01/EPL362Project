package Entities;

public class Clinic {	
	String name;
	String city;
	String location;
	long telephone;
	
	public Clinic(String name, String city, String location, long telephone) {
		this.name = name;
		this.city = city;
		this.location = location;
		this.telephone = telephone;
	}
}
