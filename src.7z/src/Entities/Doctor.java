package Entities;

import java.io.Serializable;
import java.util.ArrayList;

public class Doctor extends Staff implements Serializable{

	private static final long serialVersionUID = 1L;
	ArrayList<Patient> patients;
	static Clinic clinic = new Clinic("Makario", "nicosia", "saf", 99990000);
	static AccountType x = (AccountType.ClinicalStaff);

	public Doctor() {
		super("Andreas", "Costi", 1003060, true, true, true, clinic, x);
	}

	public Doctor(String name, String surname, int ID, boolean canEdit, boolean canAccess, boolean isAtWork,
			ArrayList<Patient> patients, Clinic clinic, AccountType type) {

		super(name, surname, ID, canEdit, canAccess, isAtWork, clinic, type);
		this.patients = patients;

	}
}
