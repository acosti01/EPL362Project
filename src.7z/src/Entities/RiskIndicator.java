package Entities;

public enum RiskIndicator {
	VeryLow, Low, High, VeryHigh
};
