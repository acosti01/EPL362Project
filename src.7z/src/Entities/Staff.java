package Entities;

import java.util.ArrayList;

public class Staff {

	String name;
	String surname;
	int ID;
	boolean canEdit;
	boolean canAccess;
	boolean isAtWork;
	Clinic clinic;
	String type;

	public Staff() {
		this.name = "sfsdfsdf";
		this.type="CLINICAL_STAFF";
	}

	public Staff(ArrayList<String> info) {
		this.name = info.remove(0);	
		this.type="CLINICAL_STAFF";

	}

	public Staff(String name2, String surname2, int iD2, boolean canEdit2, boolean canAccess2, boolean isAtWork2,
			Clinic clinic2, AccountType type2) {
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public boolean isCanEdit() {
		return canEdit;
	}

	public void setCanEdit(boolean canEdit) {
		this.canEdit = canEdit;
	}

	public boolean isCanAccess() {
		return canAccess;
	}

	public void setCanAccess(boolean canAccess) {
		this.canAccess = canAccess;
	}

	public boolean isAtWork() {
		return isAtWork;
	}

	public void setAtWork(boolean isAtWork) {
		this.isAtWork = isAtWork;
	}

	public int getClinic() {
		return clinic;
	}

	public void setClinic(int clinic) {
		this.clinic = clinic;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
