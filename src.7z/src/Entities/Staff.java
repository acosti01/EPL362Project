package Entities;

import java.io.Serializable;

public class Staff implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String name;
	String surname;
	int ID;
	boolean canEdit;
	boolean canAccess;
	boolean isAtWork;
	Clinic clinic;
	AccountType type;
	
	public Staff(String name, String surname, int ID, boolean canEdit,
			boolean canAccess, boolean isAtWork, Clinic clinic, AccountType type) {

		this.name = name;
		this.surname = surname;
		this.ID = ID;
		this.canAccess = canAccess;
		this.canEdit = canEdit;
		this.isAtWork = isAtWork;
		this.clinic = clinic;
		this.type = type;
	}
	public String getName(){
		String a=this.name;
		if (a==null)return "aaaaa";
		else return "bbbbbb";
				
	}
}
