package Entities;

public enum AccountType {
	ClinicalStaff,
	Receptionist,
	MedicalRecordsStaff,
	Management
};
