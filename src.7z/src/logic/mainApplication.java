package logic;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.sql.SQLException;
import java.util.ArrayList;

import Entities.Staff;
import rmiinterface.RMIInterface;
import GUI.ClinicalStaff_GUI;
import GUI.homepage;

public class mainApplication {
	private static RMIInterface look_up;
	static ArrayList<String> s;

	public static void main(String[] args)
			throws InterruptedException, MalformedURLException, RemoteException, NotBoundException, SQLException {
		look_up = (RMIInterface) Naming.lookup("//localhost/MyServer");
		boolean logged_in = false;
		log_in login = new log_in();
		homepage h = new homepage(login);
		while (!logged_in) {			
			h.waitForInput();
			s = look_up.validate(login.getUsername(), login.getPassword());
			if (s != null)
				logged_in = true;
				h.alertForWrongLogin();
		}
		h.setVisible(false);
		Staff currentUser = new Staff(s);
		switch (currentUser.getType()) {
		case "CLINICAL_STAFF":
			new ClinicalStaff_GUI(currentUser);
		}
	}
}
