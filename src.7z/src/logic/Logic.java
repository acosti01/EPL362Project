package logic;

public class Logic {
	
}
